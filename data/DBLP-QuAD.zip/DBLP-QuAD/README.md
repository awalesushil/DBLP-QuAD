# DBLP-QuAD

DBLP-QuAD contains 10,000 SPARQL query - question pairs along with answers fetched from DBLP KG via a Virtuoso SPARQL endpoint. The dataset is split into 7,000 training, 1,000 validation and 2,000 test examples. The dataset is available as JSON files.